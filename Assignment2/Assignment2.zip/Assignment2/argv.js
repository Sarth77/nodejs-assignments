
const Result  = process.argv[2];
console.log('Hello'+" "+Result)