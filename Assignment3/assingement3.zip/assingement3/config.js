const dotenv = require('dotenv');
dotenv.config();
module.exports = {
  Result: process.env.RESULT,
};